# Author: Relic Perisa ☩

import os
import glob
from datetime import datetime
import pyperclip

def save_session():
    text = pyperclip.paste()
    if not text.strip():
        print("Error: Clipboard is empty!")
        return

    # 1. Define the target directory path
    # "~" automatically resolves to your /home/user directory
    directory = os.path.expanduser("~/Documents/Destination_Folder")

    # 2. Check if the directory exists; if not, create it
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"Created new directory: {directory}")

    # 3. Find the most recent file inside that directory
    search_pattern = os.path.join(directory, "recorded_*.txt")
    file_list = glob.glob(search_pattern)
    latest_file = max(file_list, key=os.path.getctime) if file_list else None

    title_time = datetime.now().strftime("%d.%m.%Y. at %H:%M:%S")
    
    choice = ""
    if latest_file:
        latest_file_name = os.path.basename(latest_file)
        print(f"Found latest file in archive: {latest_file_name}")
        choice = input("Do you want to Append to this file (A) or create a New one (N)? [A/N]: ").lower()

    if choice == 'a' and latest_file:
        file_path = latest_file
        mode = "a"
        message = f"Appended to: {os.path.basename(file_path)}"
    else:
        time_name = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        file_name = f"recorded_{time_name}.txt"
        file_path = os.path.join(directory, file_name)
        mode = "w"
        message = f"Created new file: {file_name}"

    try:
        with open(file_path, mode, encoding="utf-8") as f:
            f.write(f"\n\n--- NEW ENTRY: {title_time} ---\n")
            f.write(text)
            f.write("\n" + "="*40)
        print(f"{message} (in folder Documents/Destination_Folder)")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    save_session()